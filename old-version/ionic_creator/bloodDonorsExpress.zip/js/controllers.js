angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('settingsCtrl', function($scope) {

})
      
.controller('mapOfDonorsCtrl', function($scope) {

})
   
.controller('loginCtrl', function($scope) {

})
   
.controller('createUserCtrl', function($scope) {

})
   
.controller('userDetailCtrl', function($scope) {

})
   
.controller('messagesCtrl', function($scope) {

})
 